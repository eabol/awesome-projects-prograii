public class Accesories extends Product {

    public Accesories(String name, double price, int id) {
        super(name, price, id);
    }
}
