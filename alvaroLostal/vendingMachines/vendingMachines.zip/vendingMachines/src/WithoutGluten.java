public class WithoutGluten extends Food{
}
