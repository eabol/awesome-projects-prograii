public class Alert extends Exception {
}
