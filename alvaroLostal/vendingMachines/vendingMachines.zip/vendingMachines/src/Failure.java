public class Failure {
}
