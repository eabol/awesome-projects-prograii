public class Machine {
    private int amount;
}