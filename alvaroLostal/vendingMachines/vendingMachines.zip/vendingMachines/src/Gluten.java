public class Gluten extends Food {
}
