public interface Salable {
    public boolean isSalable();
    public void replanish(int newQuantity);
}
