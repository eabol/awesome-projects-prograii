public class Food extends Product {
    public Food(String name, double price, int id) {
        super(name, price, id);
    }
}