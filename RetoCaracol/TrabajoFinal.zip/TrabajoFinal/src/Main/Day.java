package Main;

 public class Day {
     int day=1;


    public static void nextDay(){
        day++;
    }
    public static int getDay() {
        return day;
    }
}
