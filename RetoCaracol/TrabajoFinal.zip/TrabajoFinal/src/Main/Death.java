package Main;

public class Death extends Exception{
    public Death(String message){
        super(message);
    }
}
