package Main;

public enum Warning {
    HEAVY_RAIN, WEAK_RAIN,NO_RAIN,CAR_PASS,CAR_NOT_PASS
}
