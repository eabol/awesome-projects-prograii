package Main;

public class Alive extends Exception{
    public Alive(String message){
        super(message);
    }
}
