package Main;

public enum State {
    ALIVE,DEATH
}
